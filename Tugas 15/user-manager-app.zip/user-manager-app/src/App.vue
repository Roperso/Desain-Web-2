<script setup>
import HelloWorld from './components/HelloWorld.vue'
import UserList from './views/UserList.vue';
import AddList from './views/AddUser.vue'
import Sidebar from './components/Sidebar.vue';
</script>

<template>
  <router-view/>
</template>

<style scoped>
</style>
